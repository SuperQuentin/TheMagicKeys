import os
import shutil

input_path = "..\\wav_sorted_nico"
output_path = ".\\"

for file_name in os.listdir(input_path):
    ext = file_name.split('.')[1]
    if ext == "wav":
        underscore_split = file_name.split('_')
        number = int(underscore_split[0])
        new_number = "%03d" % (number + 3)
        new_file_name = "%s_%s_%s_%s" % (new_number, underscore_split[1], underscore_split[3], underscore_split[5])
        
        src_file_path = os.path.join(input_path, file_name)
        dst_file_path = os.path.join(output_path, new_file_name)

        print("%s->%s" % (src_file_path, dst_file_path))
        shutil.copy(src_file_path, dst_file_path)
    