import os
import shutil

input_path = "..\\velocity_16_all_notes_mono_remove_end"
output_path = ".\\"

note_sequence = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

# Build the file list
src_file_name_list = []
for filename in os.listdir(input_path):
    file_path = os.path.join(input_path, filename)
    if os.path.isfile(file_path):
        src_file_name_list.append(filename)
    #end if
#end for

for name in src_file_name_list:
    print(name)
# end for
print()

# Build the key list (85 keys): A0..A7.
note_list = ['A0', 'A#0', 'B0']
for octave in range(1, 8):
    for note in note_sequence:
        note = "%s%d" % (note, octave)
        note_list.append(note)
    # end for
#end for
note_list.pop()
note_list.pop()

for name in note_list:
    print(name)
# end for
print()

# Build the list of files in the right order
file_list_sorted = []
for note in note_list:
    for file_name in src_file_name_list:
        if note in file_name:
            file_list_sorted.append(file_name)
        #end if
    #end if
#end for 

for name in file_list_sorted:
    print(name)
# end for
print()

for idx in range(0, 85):
    
    src_name = file_list_sorted[idx]
    src_path = os.path.join(input_path, src_name)
    
    dst_name = "%03d_%s" % (idx + 1, src_name)
    dst_path = os.path.join(output_path, dst_name)

    print("Copying %s -> %s" % (src_name, dst_path))
    shutil.copy(src_path, dst_path)
#end for
